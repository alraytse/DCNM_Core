#!/usr/bin/env python
"""

Jeff Kala | Jose Lima
Tue Feb 19 8:59:03 AM 2019
Updated: 11/22/19

collection of DNCM boilerplate calls

    Example:
        1) import core.dcnm_calls

            fabric_list = core.dcnm_calls.get_fabrics(connection_obj)

        2) from core.dcnm_calls import get_fabrics

            fabric_list = get_fabrics(connection_obj)


    Todo:
        * todo
"""
import json
from getpass import getpass
from .session import Session
from .utilities import time_me


def get_crentials(creds_dict=None):
    """Used to specify a credentials file if file doesn't exist we will use normal input()
       to gather details.
    """
    try:
        import yaml
        import os
        file = os.path.expanduser("~/creds.key")
        with open(file) as f:
            return yaml.safe_load(f)
    except Exception as e:
        pass


def get_connection():
    """Connection handler to handle intial connection to DCNM and
       creating connection_obj and getting fabric_name

       +Checks minimun python version 3.6.x to support f-string formatting.
       SystemExit uses % format incase this file is ran in a system with no f-string support.

       Args (none)

       Returns:
        connection_obj (object)
        fabric_name (str)
    """
    import sys

    _PY3_MIN = sys.version_info[:2] >= (3, 6)
    if not _PY3_MIN:
        raise SystemExit(
            "ERROR: DCNM API package requires a minimum of Python3 version 3.6. Current version: %s"
            % "".join(sys.version.splitlines())
        )
    creds = get_crentials()
    if creds:
        user = creds["dcnm_user"]
        password = creds["dcnm_pwd"]
        base_url = creds["dcnm_url"]
    else:
        print('\nEnter "AD" credentials for DCNM Changes\n')
        user = input("Username: ")
        password = getpass()
        base_url = input("DCNM URL ( include https:// ): ")
        base_url = base_url.strip()
    sess = Session(base_url, user, password)
    sess.login()
    sess.update_lan_creds()
    fabric_list = get_fabrics(sess)
    fabric_name = None
    while not fabric_name:
        print("\n")
        print(", ".join(fabric_list))
        print("\n")
        fabric_name = input(f"\nEnter the fabric name from list above:\n")
        if fabric_name not in fabric_list:
            print("Invalid fabric name, check spelling.. name is case sensitive..")
            fabric_name = None
    sess.fabric = fabric_name
    return sess


def poap_device_list(connection_obj, fabric_name):
    """
    Current list of devices available for poap'ing.  Response data needs to be modified adding hostname/mgmt IP before
    POST'ing to the POST endpoint.

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
                fabric_name (str)

        Returns:
            A list of all switches that are available to POAP.
            Example:
            [ { "serialNumber": "FDO22222T3N", "model": "N9K-C93108TC-FX", "version": "7.0(3)I7(7)", "data": "{\"gateway\": \"10.128.18.254/24\", \"modulesModel\": [\"N9K-C93108TC-FX\"]}" }, { "serialNumber": "FDO22201MPN", "model": "N9K-C93108TC-FX", "version": "7.0(3)I7(7)", "data": "{\"gateway\": \"10.128.18.254/24\", \"modulesModel\": [\"N9K-C93108TC-FX\"]}" } ]
    """
    resp = connection_obj.get(f"/rest/control/fabrics/{fabric_name}/inventory/poap")
    print(resp)
    print(resp.text)
    return json.loads(resp.text)

def poap_submit(connection_obj, fabric_name, poap_definition):
    """
    Taking in the modified response data from the GET, POST the poap_definition into DCNM to start the POAP process.
    Once this call is submited refreshing the GUI will populate the new switches on the topology.

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
                fabric_name (str)
                poap_definition (JSON) - provided json object of needed values.
                    example: [{"serialNumber":"FDO22222T3N","model":"N9K-C93108TC-FX","version":"7.0(3)I7(7)","hostname":"rlf14lab","ipAddress":"10.128.18.75","password":"admin_passwd","data":"{\"gateway\": \"10.128.18.254/24\", \"modulesModel\": [\"N9K-C93108TC-FX\"]}"},{"serialNumber":"FDO22201MPN","model":"N9K-C93108TC-FX","version":"7.0(3)I7(7)","hostname":"rlf15lab","ipAddress":"10.128.18.76","password":"$chw@b!$chw@b","data":"{\"gateway\": \"10.128.18.254/24\", \"modulesModel\": [\"N9K-C93108TC-FX\"]}"}]

        Returns:
            True or False for POST operation.
    """
    poap_url = f"/rest/control/fabrics/{fabric_name}/inventory/poap"
    try:
        resp = connection_obj.post(poap_url, json.dumps(poap_definition))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)

def fabric_config_save(connection_obj, fabric_name):
    """
    This call will save the fabric configuration. NOTE: It does NOT deploy the configuration.  This would equate to clicking on 
    'save and deploy' then cancelling out before deploying.

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
                fabric_name (str)

        Returns:
            True or False for POST operation.
    """
    fab_save_url = f"/rest/control/fabrics/{fabric_name}/config-save"
    bogus_data = ''
    try:
        resp = connection_obj.post(fab_save_url, json.dumps(bogus_data))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)

def get_sw_role(connection_obj, sn):
    """
    Get the switch role from a serialNumber.

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
                sn (str) - serial number

        Returns:
            json payload with keys of {sn: role}
    """
    resp = connection_obj.get(f"/rest/control/switches/roles?serialNumber={sn}")
    return json.loads(resp.text)


def vpc_recommendation(connection_obj, sn):
    """
    Get vPC recommendation before actually configuring a vPC between nodes.

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
                sn (str) - serial number

        Returns:
            json payload to parse for needed attributes to make a decision
            example - {"lanId":0,"ethSwitchId":32360,"logicalName":"rlf12lab","ipAddress":"10.128.18.73","vdcName":null,"vdcId":0,"serialNumber":"FDO22201MK1","nxosVersion":"7.0(3)I7(7)","fabricName":null,"recommendationReason":"Already paired with FDO22213D3D","blockSelection":true,"uuid":null,"platformType":null,"useVirtualPeerlink":false,"currentPeer":false,"recommended":false}
    """
    resp = connection_obj.get(f"/rest/vpcpair/recommendation?serialNumber={sn}")
    return json.loads(resp.text)


def vpcpair(connection_obj, peer_one_sn, peer_two_sn):
    """
    Used to configure a vPC between two S/Ns.  It should be used after using vpc_recommendation() call to ensure
    that vPC peering between the SNs is recommended.

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
                peer_one_sn (str) - serial number of switch #1
                peer_two_sn (str) - serial number of switch #2
                

        Returns:
            True or False on success of call.
    """
    vpc_url = f"/rest/vpcpair"
    input_data = {"peerOneId":peer_one_sn,"peerTwoId":peer_two_sn,"useVirtualPeerlink":False}
    try:
        resp = connection_obj.post(vpc_url, json.dumps(input_data))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)


def add_template(connection_obj, payload):
    """
    Add a template to a switch via SN
    Note Payload should come in proper format

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
                payload (json) - exact payload needed for the template call.
                    example - {"source":"","serialNumber":"FDO22201MPN","entityType":"SWITCH","entityName":"SWITCH","templateName":"feature_tacacs","priority":"50","nvPairs":{}}
 
        Returns:
            True or False on success of call.
    """
    at_url = "/rest/control/policies/bulk-create"
    try:
        resp = connection_obj.post(at_url, payload)
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)


def discovery_info(connection_obj):
    """
    Get all information for discovery credentials

        Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.

        Returns:
            json object to parse for the POST call to update discovery credentials.
            NOTE: There is obfuscated data in this GET call that you need for the POST but the naming of the key attributes is different.   
    """
    resp = connection_obj.get("/fm/fmrest/san/getEthSwitchAllWithTaskInfo")
    return json.loads(resp.text)
    

def get_fabrics(connection_obj):
    """returns a list of DCNM fabrics

        returns a list of fabrics with no duplicate names by first filtering
        through a set() before the list is created, return list(set())

        Args:

            required:
                connection_obj (Class object): DCNM connection/session object from main script

            optional:
                url (str): REST URL used to get a list of fabrics, default
                supports dcnm version 10 & 11

        Examples:
            from core.dcnm_calls import get_fabrics

            connection = Session(url, username, password)
            connection.login()

            # with default URL
            fabric_list = get_fabrics(connection)

            # with alternate url
            fabric_list = get_fabrics(connection, url='/rest/new/url')

            print(fabric_list)

        Returns:
            A list of fabrics, with no duplicates
    """
    resp = connection_obj.get(f"/rest/control/fabrics")
    # return [x['fabricName'] for x in json.loads(resp.text)]
    return [x["fabricName"] for x in resp.json()]


def get_networks(connection_obj, fabric_name):
    """ Function used to get all networks for a fabric from DCNM.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str) name of the fabric.
    returns:
    A list of all networks from DCNM (WITHOUT DUPLICATES)
    """
    gn_url = f"/rest/top-down/fabrics/{fabric_name}/networks"
    resp = connection_obj.get(gn_url)
    data = json.loads(resp.text)
    return list({x["networkName"] for x in data})


def get_inventory(connection_obj, fabric_name):
    """ Function is used to get switch inventory for a fabric in DCNM.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)

    Returns:
    A list of all the inventory and basic information on each switch.
    """
    gi_url = f"/rest/control/fabrics/{fabric_name}/inventory"
    resp = connection_obj.get(gi_url)
    data = json.loads(resp.text)
    return list(",".join(x["displayValues"]) for x in data)


def get_templates(connection_obj):
    """ Function used to get all templates in DCNM.
    Args: connection_obj - is imported from main and is keeping track of the session connection to DCNM.

    returns:
    A list of all the templates form DCNM each index is one template.
    """
    get_temp_url = "/fm/fmrest/config/templates/"
    resp = connection_obj.get(get_temp_url)
    data = json.loads(resp.text)
    return list(",".join(x["name"] for x in data))


def get_template_details(connection_obj, template_name):
    """ Function used to pull full details from 1 of the templates
    provided from get_templates function.

    Args:
        connection_obj - imported from main to keep track of DCNM api session.
        template_name - exact name from get_templates that more detail
                        is required for.

    returns:
    Full details for the provided from template in json.
    """
    temp_url = f"/fm/fmrest/config/templates/{template_name}"
    resp = connection_obj.get(temp_url)
    return json.loads(resp.text)


def get_vtep(connection_obj):
    """ Function is used to pull all VTEPs in DCNM.
    Args: connection_obj - is imported from main and is keeping track of the session connection to DCNM.

    Returns:
    payload in json format.
    """
    get_vtep_url = "/rest/topology/switches/vxlan/vteps"
    resp = connection_obj.get(get_vtep_url)
    return json.loads(resp.text)


def get_vni_per_swid(connection_obj, sw_id):
    """ Function used to pull all mappings for a given switch-id.
    mapping will be:
    switch: <name>, vlan <num>, VNI <num>

    Args:  switch-id which can be parsed from get_vteps output.
           connection_obj - imported from main to keep track of DCNM api session.

    returns:
    A list of the mappings. In above syntax, each index is one full mapping.
    """
    v_list = []
    get_vni = connection_obj.get(f"/rest/topology/switches/vxlan?switch-id={sw_id}")
    vnis = json.loads(get_vni.text)
    for x in vnis:
        v_list.append(f"Switch: {x['Switch Name']}, Vlan: {x['Vlan']}, Vni: {x['Vni']}")
    return v_list


@time_me
def create_networks(connection_obj, fabric_name, nets):
    """ Function is used to create a network in DCNM.
    Args:   connection_obj (obj) - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            nets (list) of (dicts)
                Example of nets:  [{'networkName': 'TEST_API_1','vlanId':999, 'segmentId':10999}]
                    networkName (str)
                    vlanID (int)
                    segmentId (int)

    Returns:
    (dict) {'successful': [list of networks {'networkName': <name>,'vlanId':<vlan>}], 'failed': [list of failed networks {'networkName': <name>,'vlanId':<vlan>}], 'duplicates':[list of networkNames]}
    """
    # Checking to see if any of the networks passed in from 'nets' already exist in DCNM, if found won't be created again.
    existing_nets = set(
        get_networks(connection_obj, connection_obj.fabric)
    ).intersection(set(list(x["networkName"] for x in nets)))
    cn_url = f"/rest/top-down/fabrics/{fabric_name}/networks"
    # For networkTemplateconfig you cannot use the f-strings to format the string since its not
    # Allowed when the strings include '\' charcters.
    success_list = []
    failed_list = []
    dup_list = []
    # Loop through all networks to be created except for the networks that already existed. (NO BULK NETWORK CREATE API COULD BE FOUND.)
    for net in nets:
        if net["networkName"] in existing_nets:
            dup_list.append(
                {
                    "networkName": net["networkName"],
                    "vlanId": int(net["vlanId"]),
                    "segmentId": int(net["segmentId"]),
                }
            )
        else:
            # net_template_config is based on "Default_network_extention" template, with values being passed in.
            net_template_config = """{\"suppressArp\":\"false\",\"vlanId\":\"%s\",\"gatewayIpAddress\":\"\",\"networkName\":\"%s\",\"enableIR\":\"false\",\"mtu\":\"\", \
        \"isLayer2Only\":\"true\",\"intfDescription\":\"\",\"segmentId\":\"%s\",\"mcastGroup\":\"239.1.1.1\",\"gatewayIpV6Address\":\"\",\"dhcpServerAddr1\":\"\",\"nveId\":\"1\", \
        \"vrfDhcp\":\"\",\"vrfName\":\"NA\"}""" % (
                net["vlanId"],
                net["networkName"],
                net["segmentId"],
            )

            # Input_data is the body payload that needs to be sent with the API call to DCNM.
            input_data = {
                "fabric": f"{fabric_name}",
                "networkName": f"{net['networkName']}",
                "networkId": int(net["segmentId"]),
                "networkTemplate": "Default_Network_Universal",
                "networkExtensionTemplate": "Default_Network_Extension_Universal",
                "networkTemplateConfig": f"{net_template_config}",
                "vrf": "NA",
            }
            try:
                # Since there is no bulk 'network create' api call, we for-loop through the networks.  The number of api calls = number of networks from original list.
                #print(json.dumps(input_data))
                resp = connection_obj.post(cn_url, json.dumps(input_data))
                if resp.ok:
                    success_list.append(
                        {
                            "networkName": net["networkName"],
                            "vlanId": int(net["vlanId"]),
                            "segmentId": int(net["segmentId"]),
                        }
                    )
                else:
                    failed_list.append(
                        {
                            "networkName": net["networkName"],
                            "vlanId": int(net["vlanId"]),
                            "segmentId": int(net["segmentId"]),
                        }
                    )
            except Exception as e:
                print(e)
                sys.exit(0)
    return {"successful": success_list, "failed": failed_list, "duplicates": dup_list}


@time_me
def bulk_create_networks(connection_obj, fabric_name, nets):
    """ Function is used to create a network in DCNM.
    Args:   connection_obj (obj) - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            nets (list) of (dicts)
                Example of nets:  [{'networkName': 'TEST_API_1','vlanId':999, 'segmentId':10999}]
                    networkName (str)
                    vlanID (int)
                    segmentId (int)

    Returns:
    (dict) {'successful': [list of networks {'networkName': <name>,'vlanId':<vlan>}], 'failed': [list of failed networks {'networkName': <name>,'vlanId':<vlan>}], 'duplicates':[list of networkNames]}
    """
    # Checking to see if any of the networks passed in from 'nets' already exist in DCNM, if found won't be created again.
    existing_nets = set(
        get_networks(connection_obj, connection_obj.fabric)
    ).intersection(set(list(x["networkName"] for x in nets)))
    cn_url = f"/rest/top-down/bulk-create/networks"
    dup_list = []
    bulk_list = []
    # Loop through all networks to be created except for the networks that already existed. (NO BULK NETWORK CREATE API COULD BE FOUND.)
    for net in nets:
        if net["networkName"] in existing_nets:
            dup_list.append(
                {
                    "networkName": net["networkName"],
                    "vlanId": int(net["vlanId"]),
                    "segmentId": int(net["segmentId"]),
                }
            )
        else:
            net_template_config = { 'suppressArp': 'false', 
                                    'vlanId': f'{net["vlanId"]}', 
                                    'gatewayIpAddress': '', 
                                    'networkName': f'{net["networkName"]}', 
                                    'enableIR': 'false', 
                                    'mtu': '', 
                                    'isLayer2Only': 'true', 
                                    'intfDescription': '', 
                                    'segmentId': f'{net["segmentId"]}', 
                                    'mcastGroup': '239.1.1.1', 
                                    'gatewayIpV6Address': '', 
                                    'dhcpServerAddr1': '', 
                                    'nveId': '1', 
                                    'vrfDhcp': '', 
                                    'vrfName': 'NA'}

            # Input_data is the body payload that needs to be sent with the API call to DCNM.
            input_data = {
                "fabric": f"{fabric_name}",
                "networkName": f"{net['networkName']}",
                "networkId": int(net["segmentId"]),
                "networkTemplate": "Default_Network_Universal",
                "networkExtensionTemplate": "Default_Network_Extension_Universal",
                "networkTemplateConfig": f"{json.dumps(net_template_config)}",
                "vrf": "NA",
            }
            bulk_list.append(input_data)
    try:
        resp = connection_obj.post(cn_url, json.dumps(bulk_list))
    except Exception as e:
        print(e)
        sys.exit(0)
    if 'failureList' in resp.json() and 'successList' in resp.json():
        return {"successful": resp.json()["successList"], "failed": resp.json()["failureList"], "duplicates": dup_list}
    elif 'failureList' in resp.json() and 'successList' not in resp.json():
        return {"failed": resp.json()["failureList"], "duplicates": dup_list}
    else: 
        return {"successful": resp.json()["successList"], "duplicates": dup_list}

@time_me
def delete_networks(connection_obj, fabric_name, network_names):
    """ Function is used to create a network in DCNM.
    Args:   connection_obj (obj) - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            network_names (list)

    Returns:
    (dict) {'successful': [list of networks {'networkName': <name>,'vlanId':<vlan>}], 'failed': [list of failed networks {'networkName': <name>,'vlanId':<vlan>}], 'doesnt_exist:[list of networkNames]}
    """
    success_list = []
    failed_list = []
    doesnt_exist_list = []
    # Checking to see if any of the networks passed in from 'network_names' don't exist in DCNM, if found program won't try and delete an unexistent network.
    unexisting_nets = set(network_names) - set(
        get_networks(connection_obj, connection_obj.fabric)
    )
    print(unexisting_nets)
    for net in network_names:
        if net in unexisting_nets:
            doesnt_exist_list.append(net)
        else:
            cn_url = f"/rest/top-down/fabrics/{fabric_name}/networks/{net}"
            try:
                resp = connection_obj.delete(cn_url)
                if resp.ok:
                    success_list.append(net)
                else:
                    failed_list.append(net)
            except Exception as e:
                print(e)
                sys.exit(0)
    return {
        "successful": success_list,
        "failed": failed_list,
        "doesnt_exist": doesnt_exist_list,
    }


@time_me
def attach_networks(connection_obj, fabric_name, nets):
    """ Function is used to attach a network to a switch in DCNM.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            nets (list) of (dicts)
                Example of nets:  [{'networkName': 'TEST_API_1','vlanId':999, 'attachInfo': [{'serialNumber': FDO220324GK','interfaces': ''},{'serialNumber': FDO22112VQU','interfaces': ''}'']}]
                    networkName (str)
                    vlanID (int)
                    serialNumber (list) of serial numbers. We will for-loop through these later in the code.

    Returns:
    boolean: True for Success, False otherwise
    """
    # This url can take a 'bulk' style body and attach any number of networks with 1 API call.
    an_url = f"/rest/top-down/fabrics/{fabric_name}/networks/attachments"
    final_list = []
    # The Following for-loops are used to create the payload body to sent with API call.
    for net in nets:
        lan_attach_list = []
        for switch in net["attachInfo"]:
            input_data = {
                "fabric": f"{fabric_name}",
                "networkName": f"{net['networkName']}",
                "serialNumber": f"{switch['serialNumber']}",
                "switchPorts": f"{','.join(switch['interfaces'])}",
                "detachSwitchPorts": "",
                "vlan": int(net["vlanId"]),
                "dot1QVlan": 0,
                "untagged": False,
                "deployment": True,
            }
            lan_attach_list.append(input_data)
        final_dict = {
            "networkName": f"{net['networkName']}",
            "lanAttachList": lan_attach_list,
        }
        final_list.append(final_dict)
    try:
        # One single POST will have the body of ALL networks, and then ALL switches for each network to be deployed to.
        resp = connection_obj.post(an_url, json.dumps(final_list))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)
        sys.exit(0)


@time_me
def deattach_networks(connection_obj, fabric_name, nets):
    """ Function is used to attach a network to a switch in DCNM.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            nets (list) of (dicts)
                Example of nets:  [{'networkName': 'TEST_API_1','vlanId':999, 'attachInfo': [{'serialNumber': FDO220324GK','interfaces': ''},{'serialNumber': FDO22112VQU','interfaces': ''}'']}]
                    networkName (str)
                    vlanID (int)
                    serialNumber (list) of serial numbers. We will for-loop through these later in the code.

    Returns:
    boolean: True for Success, False otherwise
    """
    # This url can take a 'bulk' style body and attach any number of networks with 1 API call.
    an_url = f"/rest/top-down/fabrics/{fabric_name}/networks/attachments"
    final_list = []
    # The Following for-loops are used to create the payload body to sent with API call.
    for net in nets:
        lan_attach_list = []
        for switch in net["attachInfo"]:
            input_data = {
                "fabric": f"{fabric_name}",
                "networkName": f"{net['networkName']}",
                "serialNumber": f"{switch['serialNumber']}",
                "switchPorts": "",
                "detachSwitchPorts": f"{','.join(switch['interfaces'])}",
                "vlan": int(net["vlanId"]),
                "dot1QVlan": 0,
                "untagged": False,
                "deployment": True,
            }
            lan_attach_list.append(input_data)
        final_dict = {
            "networkName": f"{net['networkName']}",
            "lanAttachList": lan_attach_list,
        }
        final_list.append(final_dict)
    try:
        # One single POST will have the body of ALL networks, and then ALL switches for each network to be deployed to.
        resp = connection_obj.post(an_url, json.dumps(final_list))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)
        sys.exit(0)


@time_me
def deattach_interfaces(connection_obj, fabric_name, nets):
    """ Function is used to attach a network to a switch in DCNM.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            nets (list) of (dicts)
                Example of nets:  [{'networkName': 'TEST_API_1','vlanId':999, 'attachInfo': [{'serialNumber': FDO220324GK','interfaces': ''},{'serialNumber': FDO22112VQU','interfaces': ''}'']}]
                    networkName (str)
                    vlanID (int)
                    serialNumber (list) of serial numbers. We will for-loop through these later in the code.

    Returns:
    boolean: True for Success, False otherwise

    NOTE:
    If input_data has deployments = True it will de-attach overlays ONLY, Leaving network deployed to switch.
    If input_data has deployments = False it will de-attach overlays, AND undeploy network from the switch.
    """
    # This url can take a 'bulk' style body and attach any number of networks with 1 API call.
    an_url = f"/rest/top-down/fabrics/{fabric_name}/networks/attachments"
    final_list = []
    # The Following for-loops are used to create the payload body to sent with API call.
    for net in nets:
        lan_attach_list = []
        for switch in net["attachInfo"]:
            input_data = {
                "fabric": f"{fabric_name}",
                "networkName": f"{net['networkName']}",
                "serialNumber": f"{switch['serialNumber']}",
                "switchPorts": "",
                "detachSwitchPorts": f"{','.join(switch['interfaces'])}",
                "vlan": int(net["vlanId"]),
                "dot1QVlan": 0,
                "untagged": False,
                "deployment": True,
            }
            lan_attach_list.append(input_data)
        final_dict = {
            "networkName": f"{net['networkName']}",
            "lanAttachList": lan_attach_list,
        }
        final_list.append(final_dict)
    try:
        # One single POST will have the body of ALL networks, and then ALL switches for each network to be deployed to.
        resp = connection_obj.post(an_url, json.dumps(final_list))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)
        sys.exit(0)

@time_me
def preview(connection_obj, fabric_name, network_names):
    """ Function is used to preview the deployment of the network.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            network_name (list)
    Returns:
    json payload to overview the changes before continuing (logic in main()) or returns False if unsuccessful.
    """
    pv_url = f'/rest/top-down/fabrics/{fabric_name}/networks/preview?network-names={",".join(network_names)}'
    try:
        resp = connection_obj.get(pv_url,timeout=1200)
        if resp.ok:
            return json.loads(resp.text)
        else:
            return False
    except Exception as e:
        print(e)
        sys.exit(0)

@time_me
def preview_fabric(connection_obj, fabric_name):
    """ Function is used to preview the deployment of the network.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
    Returns:
    json payload to overview the changes before continuing (logic in main()) or returns False if unsuccessful.
    """
    pv_url = f'/rest/control/fabrics/{fabric_name}/config-preview?forceShowRun=false'
    try:
        resp = connection_obj.get(pv_url,timeout=1200)
        if resp.ok:
            return json.loads(resp.text)
        else:
            return False
    except Exception as e:
        print(e)
        sys.exit(0)

@time_me
def deploy_networks(connection_obj, fabric_name, network_names):
    """ Function is used to deploy the network that was created.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            network_name (list)
    Returns:
    boolean: True for Success, False otherwise
    """
    dn_url = f"/rest/top-down/fabrics/{fabric_name}/networks/deployments"
    input_data = {"networkNames": f'{",".join(network_names)}'}
    try:
        resp = connection_obj.post(dn_url, json.dumps(input_data))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)
        sys.exit(0)

@time_me
def single_switch_deploy(connection_obj, fabric_name, serial):
    """ Function is used to deploy all pending changes to a given switch(serial number) for a given fabric.
    Args:   connection_obj - is imported from main and is keeping track of the session connection to DCNM.
            fabric_name (str)
            serial (str) - serialnumber
    Returns:
    boolean: True for Success, False otherwise
    """
    fab_deploy_url = f"/rest/control/fabrics/{fabric_name}/config-deploy/{serial}?forceShowRun=false"
    bogus_data = ''
    try:
        resp = connection_obj.post(fab_deploy_url, json.dumps(bogus_data))
        if resp.ok:
            return True
        else:
            return False
    except Exception as e:
        print(e)
        sys.exit(0)