#!/usr/bin/env python
"""This class generates a API connection object

Created By: Jose Lima | Updated by Jeff Kala for JIRA
Tue Nov 12 4:13:14 PM 2018

Tested on: Python v3.6.3

This is the core module used for setup, tracking and teardown of API calls to JIRA

    Example:
        A couple of ways to call this module from other scripts in the /jira/ root
        folder:

        1) from core.session import JiraManager
            connection = JiraManager(url, usr, pass)

        2) from core import session
            connection = session.JiraManager(url, usr, pass)

    Notes:
        General usage:
            from core.session import JiraManager

            connection = JiraManager(url, usr, pass)

    Todo:
        *
"""
# general imports
import json
import requests

# import from our own API tools
from ..core.utilities import retry_on_server_error, retry_on_auth_and_error, retry_on_login_error

# suppresses invalid cert warnings, depricated..., using verify=False
requests.packages.urllib3.disable_warnings()

__author__ = 'Jose Lima|Jeff Kala'


class JiraManager:
    """API session manager base class

    This class creates a connection object used to manage API sessions
    It should be used to create new classes and take advantage of inheritance to
    support future versions of JIRA and adapt to any changes.

        Attributes:
            self.base_url (str): server URL e.g. https://jira.schwab.com/rest/
            self.user (str): API username, ad.first.last, or first.last
            self._passwd (str): API password, through JH or first.last AD
            self.headers (json): required headers to stablish API call with JIRA

        Notes:

            @retry_on_server_error = decorator used to retry on any HTTP 500+ errors
            @retry_on_auth_and_error = decorator used to retry on any HTTP 400+ errors

                decorators can be safely removed or commented out with out
                impacting API call functionality, however they are there to provide
                session reliability in the event the server is busy during any of
                the API calls.
    """

    def __init__(self, url, user, passwd):
        self.base_url = url
        self.user = user
        self._passwd = passwd
        self.headers = {
            'Accept': 'application/json',
            'Content-Type': 'application/json; charset=UTF-8',
        }

    @retry_on_auth_and_error
    def get(self, url):
        url = self.base_url + url
        resp = requests.get(
            url, headers=self.headers, auth=(self.user, self._passwd), timeout=30, verify=False)
        if not resp.ok:
            print(f'Error: {url} --> {resp.text}')
        return resp

    @retry_on_auth_and_error
    def put(self, url, data, timeout=1200):
        url = self.base_url + url
        resp = requests.put(
            url,
            headers=self.headers,
            data=data,
            timeout=timeout,
            auth=(self.user, self._passwd),
            verify=False)
        if not resp.ok:
            print(f'Error: {url} --> {resp.text}')
        return resp

    @retry_on_auth_and_error
    def post(self, url, data, timeout=1200):
        url = self.base_url + url
        resp = requests.post(
            url,
            headers=self.headers,
            data=data,
            timeout=timeout,
            auth=(self.user, self._passwd),
            verify=False)
        if not resp.ok:
            print(f'Error: {url} --> {resp.text}')
        return resp

    @retry_on_server_error
    def delete(self, url):
        url = self.base_url + url
        resp = requests.delete(url, headers=self.headers, auth=(self.user, self._passwd), verify=False)
        if not resp.ok:
            print(f'Error: {url} --> {resp.text}')
        return resp